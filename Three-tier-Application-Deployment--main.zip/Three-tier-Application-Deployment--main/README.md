checkout the blog written on this project --> https://medium.com/@aakibkhan1/project-8-three-tier-application-deployment-on-kubernetes-bf9323de40e0
